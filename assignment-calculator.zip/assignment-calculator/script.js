function appendToDisplay(input) {
    const operators = ['+', '-', '*', '/'];
    let currentValue = display.value;
    let lastChar = currentValue.slice(-1);

    // Prevent multiple operators in a row
    if (operators.includes(input)) {
        if (!currentValue || operators.includes(lastChar)) {
            // Replace last operator or prevent starting with an operator
            display.value = currentValue.slice(0, -1) + input;
            return;
        }
    }

    // Prevent multiple decimals in the same number
    if (input === '.') {
        let lastNumber = currentValue.split(/[+\-*/]/).pop();
        if (lastNumber.includes('.')) {
            return;
        }
    }

    display.value += input;
}

function calculate() {
    try {
        // Use Function constructor for safer evaluation
        const result = new Function('return ' + display.value)();
        display.value = result;
    } catch (error) {
        display.value = "Error";
        console.error("Calculation error:", error);
    }
}

function clearAll() {
    display.value = "";
}

function deleteLastCharacter() {
    display.value = display.value.slice(0, -1); // Remove the last character
}

// function appendToDisplay(input) {
//     // Get the current value of the display
//     let currentValue = display.value;

//     // Check if the input is a decimal point

// }








// let display = document.getElementById("display");

// function appendToDisplay(input) {
//     // Get the current value of the display
//     let currentValue = display.value;

//     // Check if the input is a decimal point
//     if (input === '.') {
//         // Split the current value by operators to find the last number
//         let lastNumber = currentValue.split(/[+-*/]/).pop();
        
//         // If the last number already contains a decimal point, do not append
//         if (lastNumber.includes('.')) {
//             return; // Exit the function without appending
//         }
//     }

//     // Append the input to the display
//     display.value += input;
// }

// function calculate() {
//     try {
//         // Use Function constructor for safer evaluation
//         const result = new Function('return ' + display.value)();
//         display.value = result;
//     } catch (error) {
//         display.value = "Error";
//         console.error("Calculation error:", error);
//     }
// }

// function clearAll() {
//     display.value = "";
// }

// function deleteLastCharacter() {
//     display.value = display.value.slice(0, -1); // Remove the last character
// }